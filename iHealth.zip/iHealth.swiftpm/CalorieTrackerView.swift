import SwiftUI

struct CalorieTrackerView: View {
    @State private var calories: String = ""
    @State private var meal: String = ""
    @State private var date: Date = Date()
    @State private var entries: [Entry] = []
    
    var body: some View {
            NavigationView {
                Form {
                    Section(header: Text("Add New Entry")) {
                        TextField("Calories", text: $calories)
                            .keyboardType(.numberPad)
                        TextField("Meal", text: $meal)
                        DatePicker("Date", selection: $date, displayedComponents: [.date])
                        Button("Save Entry", action: saveEntry)
                    }
                    Section(header: Text("Entries")) {
                        if entries.isEmpty {
                            HStack{
                            Image(systemName: "plus.circle")
                             Text("Track your meals by adding the entry")   
                            }
                        }else{
                            ForEach(entries, id: \.self) { entry in
                                VStack(alignment: .leading) {
                                    Text("Calories: \(entry.calories)")
                                    Text("Meal: \(entry.meal)")
                                    Text("Date: \(entry.dateString)")
                                }
                            }
                            .onDelete(perform: deleteEntry)   
                        }
                    }
                }
                .navigationBarTitle("Calorie Tracker")
                .foregroundColor(.blue)
                .scrollContentBackground(.hidden)
                .background(.yellow)
            }
    }
    func saveEntry() {
        guard let caloriesInt = Int(calories) else { return }
        
        let newEntry = Entry(calories: caloriesInt, meal: meal, date: date)
        entries.append(newEntry)
        
        calories = ""
        meal = ""
        date = Date()
    }
    
    func deleteEntry(at offsets: IndexSet) {
        entries.remove(atOffsets: offsets)
    }
}

struct Entry: Hashable {
    var calories: Int
    var meal: String
    var date: Date
    
    var dateString: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy"
        return dateFormatter.string(from: date)
    }
}


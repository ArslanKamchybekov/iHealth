import SwiftUI

struct ContentView: View {
    @AppStorage("currentPage") var currentPage = 1
    var body: some View {
        if currentPage > totalPages{
            TabView{
                CalorieCalculatorView()
                    .tabItem { 
                        Image(systemName: "carrot.fill")
                    }
                CalorieTrackerView()
                    .tabItem { 
                        Image(systemName: "list.bullet.rectangle.portrait")
                }
                ExerciseView()
                    .tabItem { 
                        Image(systemName: "dumbbell")
                    }
            }
            .accentColor(.indigo)
        }else{
            WalkthroughScreen()
        }
    }
}
var totalPages = 3

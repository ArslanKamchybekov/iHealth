import SwiftUI

struct ExerciseView: View {
    @State var time = 0
    @State var intensity = 1
    @State var caloriesBurned = 0
    
    let intensities = ["Low", "Medium", "High"]
    
    var body: some View {
        ZStack{
            VStack {
                VStack(spacing: 24){
                    HStack{
                        Text("Exercise")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .padding(.top, 50)
                        Spacer()
                    }
                    Image(systemName: "figure.outdoor.cycle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.indigo)
                        .frame(width: 100, height: 100)
                }                
                VStack(spacing: 24) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Time (minutes)")
                            .font(.headline)
                        TextField("Enter time", value: $time, formatter: NumberFormatter())
                            .padding(10)
                            .background(Color.white)
                            .cornerRadius(10)
                            .keyboardType(.numberPad)
                    }                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Intensity")
                            .font(.headline)
                        Picker(selection: $intensity, label: Text("Intensity")) {
                            ForEach(0..<intensities.count) {
                                Text(self.intensities[$0])
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                }
                .padding(.top, 50)                
                Button(action: {
                    self.caloriesBurned = self.calculateCaloriesBurned()
                }) {
                    Text("Calculate calories burned")
                        .font(.headline)
                        .foregroundColor(.blue)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.white)
                        .cornerRadius(10)
                }
                .padding(.vertical, 24)
                
                if caloriesBurned > 0 {
                    HStack{
                        Image(systemName: "figure.run")
                        Text("Calories Burned: \(caloriesBurned)")   
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.yellow)
    }    
    func calculateCaloriesBurned() -> Int {
        let baseCaloriesBurnedPerMinute = 10
        var caloriesBurned = baseCaloriesBurnedPerMinute * time
        
        switch intensity {
        case 1:
            caloriesBurned *= 2
        case 2:
            caloriesBurned *= 3
        default:
            break
        }        
        return caloriesBurned
    }
}



import SwiftUI

struct ScreenView: View{
    var image: String
    var title: String
    var detail: String
    var topColor: Color
    var bottomColor: Color
    @AppStorage("currentPage") var currentPage = 1
    var body: some View{
        VStack(spacing: 20){
            HStack{
                if currentPage == 1 {
                    Text("Welcome to iHealth")
                        .font(.title)
                        .fontWeight(.semibold)
                        .kerning(1.4)
                        .padding(.leading, 8)
                }else{
                    Button { 
                        currentPage -= 1
                    } label: { 
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(.vertical, 10)
                            .padding(.horizontal)
                            .background(.black.opacity(0.4))
                            .cornerRadius(8)
                    }
                }
                Spacer()
                Button { 
                    currentPage = 4
                } label: { 
                    Text("Skip")
                        .foregroundColor(.gray)
                        .font(.system(size: 14))
                        .fontWeight(.bold)
                        .kerning(1.0)
                        .padding(.trailing, 8)
                }
            }
            .foregroundColor(.black)
            .padding(.top, 8)
            .padding()
            Spacer(minLength: 0)
            Image(systemName: image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 180, height: 180)
            Text(title)
                .font(.title)
                .fontWeight(.semibold)
                .foregroundColor(.black)
                .padding(.top)
            Text(detail)
                .foregroundColor(.white)
                .fontWeight(.light)
                .kerning(1.5)
                .multilineTextAlignment(.center)
            Spacer(minLength: 170)
        }
        .background(LinearGradient(colors: [topColor, bottomColor], startPoint: .topLeading, endPoint: .bottomTrailing))
        .edgesIgnoringSafeArea(.all)
    }
}

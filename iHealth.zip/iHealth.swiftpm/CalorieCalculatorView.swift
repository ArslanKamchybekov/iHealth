import SwiftUI

struct CalorieCalculatorView: View {
    @State private var age: String = ""
    @State private var weight: String = ""
    @State private var height: String = ""
    @State private var gender: Int = 0
    @State private var activityLevel: Int = 0
    
    let genderOptions = ["Male", "Female"]
    let activityLevelOptions = ["Sedentary", "Moderately Active", "Active", "Very Active"]
    
    var body: some View {
        ZStack{
            VStack{
                NavigationView {
                    Form {
                        Section(header: Text("Personal Information")) {
                            TextField("Age", text: $age)
                                .keyboardType(.numberPad)
                            TextField("Weight (in pounds)", text: $weight)
                                .keyboardType(.numberPad)
                            TextField("Height (in inches)", text: $height)
                                .keyboardType(.numberPad)
                            Picker("Gender", selection: $gender) {
                                ForEach(0..<genderOptions.count) {
                                    Text(self.genderOptions[$0])
                                }
                            }
                            Picker("Activity Level", selection: $activityLevel) {
                                ForEach(0..<activityLevelOptions.count) {
                                    Text(self.activityLevelOptions[$0])
                                }
                            }
                        }
                        Section(header: Text("Calories")) {
                            Text("Calories per day: \(calculateCalories())")
                        }
                    }
                    .navigationBarTitle("Calorie Calculator")
                    .foregroundColor(.blue)
                    .scrollContentBackground(.hidden)
                    .background(.yellow)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.yellow)
    }
    func calculateCalories() -> String {
        let ageInt = Int(age) ?? 0
        let weightInt = Int(weight) ?? 0
        let heightInt = Int(height) ?? 0
        
        var bmr: Double = 0
        
        if gender == 0 {
            // Male
            bmr = (4.536 * Double(weightInt)) + (15.88 * Double(heightInt)) - (5 * Double(ageInt)) + 5
        } else {
            // Female
            bmr = (4.536 * Double(weightInt)) + (15.88 * Double(heightInt)) - (5 * Double(ageInt)) - 161
        }
        
        var activityMultiplier: Double = 0
        
        switch activityLevel {
        case 0:
            activityMultiplier = 1.2
        case 1:
            activityMultiplier = 1.375
        case 2:
            activityMultiplier = 1.55
        case 3:
            activityMultiplier = 1.725
        default:
            activityMultiplier = 1.2
        }
        
        let calories = bmr * activityMultiplier
        
        return String(format: "%.0f", calories)
    }
}

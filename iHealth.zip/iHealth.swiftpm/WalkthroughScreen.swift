import SwiftUI

struct WalkthroughScreen: View{
    @AppStorage("currentPage") var currentPage = 1
    var body: some View{
        ZStack{
            if currentPage == 1{
                ScreenView(image: "applelogo", title: "Estimate", detail: "Amount of calories", topColor: .yellow, bottomColor: .orange)
                    .transition(.scale)
            }
            if currentPage == 2{
                ScreenView(image: "figure.run", title: "Choose", detail: "Your activity pace", topColor: .yellow, bottomColor: .orange)
                    .transition(.scale)
            }
            if currentPage == 3{
                ScreenView(image: "tree", title: "Change", detail: "Your life", topColor: .yellow, bottomColor: .orange)
                    .transition(.scale)
            }
            
        }
        .overlay(
            Button(action: { 
                if currentPage <= totalPages{
                    currentPage += 1
                }else{
                    currentPage = 1
                }
            }, label: { 
                Image(systemName: "chevron.right")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                    .frame(width: 50, height: 50)
                    .background(.white)
                    .clipShape(Circle())
                    .overlay(
                        ZStack{
                            Circle()
                                .stroke(.black.opacity(0.04), lineWidth: 4)
                            Circle()
                                .trim(from: 0, to: CGFloat(currentPage) / CGFloat(totalPages))
                                .stroke(.white, lineWidth: 4)
                                .rotationEffect(.init(degrees: -90))
                        }
                            .padding(-16)
                    )
            })
            .padding(56)
            ,alignment: .bottom
        )
    }
}
